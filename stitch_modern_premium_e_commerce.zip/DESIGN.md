---
name: Vivid Editorial
colors:
  surface: '#faf8ff'
  surface-dim: '#d8d9e6'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#ecedfa'
  surface-container-high: '#e6e7f4'
  surface-container-highest: '#e0e2ef'
  on-surface: '#181b24'
  on-surface-variant: '#5b4042'
  inverse-surface: '#2d303a'
  inverse-on-surface: '#eff0fd'
  outline: '#8f6f72'
  outline-variant: '#e3bdc0'
  surface-tint: '#bd0043'
  primary: '#b90041'
  on-primary: '#ffffff'
  primary-container: '#df2457'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2ba'
  secondary: '#006b55'
  on-secondary: '#ffffff'
  secondary-container: '#70fad2'
  on-secondary-container: '#00725b'
  tertiary: '#575b70'
  on-tertiary: '#ffffff'
  tertiary-container: '#707389'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9dc'
  primary-fixed-dim: '#ffb2ba'
  on-primary-fixed: '#400011'
  on-primary-fixed-variant: '#910031'
  secondary-fixed: '#70fad2'
  secondary-fixed-dim: '#50ddb7'
  on-secondary-fixed: '#002018'
  on-secondary-fixed-variant: '#005140'
  tertiary-fixed: '#dee1fa'
  tertiary-fixed-dim: '#c2c5de'
  on-tertiary-fixed: '#161b2d'
  on-tertiary-fixed-variant: '#42465a'
  background: '#faf8ff'
  on-background: '#181b24'
  surface-variant: '#e0e2ef'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1280px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

The design system is engineered for a high-fashion, premium e-commerce experience that balances energetic retail pulses with minimalist editorial discipline. It targets a fashion-forward audience that values trend-setting aesthetics and seamless, trustworthy transactions.

The visual style is **Modern Corporate** with a **High-Contrast** edge. It utilizes a pure white canvas to allow product photography to remain the focal point, while employing sharp grid alignments and vibrant accent pops to navigate the user through the shopping funnel. The emotional response is one of sophistication, speed, and reliability.

## Colors

This design system utilizes a high-energy palette against a pristine background:

- **Primary (#FF3F6C):** A vibrant coral-pink used for critical actions, brand presence, and primary CTAs. It signifies energy and fashion.
- **Secondary (#20BD99):** A fresh teal used for success states, trust markers (like "Verified" or "In Stock"), and secondary highlights.
- **Tertiary (#282C3F):** A deep charcoal used for primary text and headers to provide better readability and premium feel than pure black.
- **Neutral (#9496A2):** Used for secondary text, borders, and inactive states to maintain a clean hierarchy.
- **Background (#FFFFFF):** A strict pure white base to ensure a high-end, "gallery" feel for product imagery.

## Typography

The typography system relies on **Inter** to deliver a systematic, utilitarian, yet modern feel. 

- **Headlines:** Use heavy weights (Bold/ExtraBold) with slight negative letter spacing to create a high-fashion editorial impact.
- **Brand Identifiers:** On product cards, the brand name should use `label-bold` to distinguish it from the product description.
- **Price Points:** Always use `headline-md` or `body-lg` in Bold weight to ensure clear value communication.
- **Mobile Scaling:** Headlines scale down aggressively for mobile to ensure product names do not wrap excessively, maintaining the clean vertical rhythm.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy on desktop and a **Fluid Grid** on mobile.

- **Desktop:** A 12-column grid with a 1280px max-width. Product listings typically span 3 columns (4 items per row) to maximize visual size.
- **Mobile:** A 2-column grid for product listings to allow for rapid scrolling and high-density browsing without sacrificing image clarity.
- **Spacing Rhythm:** Based on a 4px baseline. Use `stack-md` (16px) for most component internal spacing and `stack-lg` (32px) for section breathing room.
- **Margins:** Consistent 16px side margins on mobile ensure content doesn't bleed to the edge, maintaining the premium "framed" look.

## Elevation & Depth

The design system uses **Tonal Layers** and **Low-contrast outlines** rather than heavy shadows to maintain a clean, flat aesthetic.

- **Product Cards:** Use a thin 1px border (#EAEAEC) rather than a shadow. Depth is achieved on hover by slightly increasing the border contrast or adding a very subtle, diffused 4px Y-offset shadow.
- **Navigation/Modals:** A soft "Level 2" shadow (0px 4px 12px rgba(0,0,0,0.08)) is reserved for floating elements like dropdowns and sticky headers to separate them from the scrolling content.
- **Surface Tiers:** Use a light grey (#F5F5F6) for secondary background sections to create a clear visual break between the main white content areas.

## Shapes

The shape language is primarily **Soft (Level 1)**, leaning towards a professional and structured look.

- **Standard Elements:** Buttons and Input fields use a 4px (0.25rem) radius to keep the UI feeling sharp and modern.
- **Special Elements:** Search bars and specific "Pill" tags (like "New" or "Sale") use the `rounded-xl` (12px) or full pill radius to create visual variety and draw the eye to interactive search areas.
- **Product Images:** Should remain sharp (0px) or very slightly softened (2px) to maintain the "fashion photography" professional standard.

## Components

- **Buttons:** Primary buttons are solid `#FF3F6C` with white text, using `label-bold` for the label. Secondary buttons use a 1px border of the same color with a transparent background.
- **Search Bar:** A prominent rounded container (radius: 12px) with a light grey background (#F5F5F6) and a subtle search icon. It remains fixed or highly accessible at the top.
- **Product Cards:** A vertical stack consisting of a full-bleed image, followed by a padded text area. The Brand Name is Bold/Charcoal, the Product Name is Regular/Neutral, and the Price is Bold/Charcoal.
- **Checkout Progress Bar:** A horizontal multi-step indicator using the Teal (#20BD99) color for completed states and the Pink (#FF3F6C) for the current active step.
- **Chips & Tags:** Small, low-height containers with `label-sm` text. Discount tags should use a light version of the Primary color (Pink) to signify urgency.
- **Input Fields:** Rectangular with a 1px border (#D4D5D9). On focus, the border transitions to Tertiary charcoal, never the primary accent, to keep the data-entry experience calm.